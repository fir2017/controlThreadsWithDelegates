﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;


namespace controlThreadsWithDelegates
{
    public partial class controlButonDelegate : UserControl
    {
        public controlButonDelegate()
        {
            InitializeComponent();
        }
        public Form1 f;
        public Control c;
        public int distance=0;
        public int speed=0;

        public void startAnimation()
        { 
            //will move to right
            try
            {
                while (Left < distance)
                {
                    Left += speed;
                    Form1.changemaytext(c, this.Name + this.Left.ToString());
                    f.Refresh();
                    Thread.Sleep(20);
                };
            }
            catch { }
        }

        private void controlButonDelegate_Click(object sender, EventArgs e)
        {
            startAnimation();
        }


        private void controlButonDelegate_Load(object sender, EventArgs e)
        {
            try {
                f = (Form1)ParentForm;
            }
            catch { }
        }
    }
}
