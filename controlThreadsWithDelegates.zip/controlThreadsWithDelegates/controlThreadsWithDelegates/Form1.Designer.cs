﻿namespace controlThreadsWithDelegates
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.controlButonDelegate1 = new controlThreadsWithDelegates.controlButonDelegate();
            this.controlButonDelegate2 = new controlThreadsWithDelegates.controlButonDelegate();
            this.controlButonDelegate3 = new controlThreadsWithDelegates.controlButonDelegate();
            this.controlButonDelegate4 = new controlThreadsWithDelegates.controlButonDelegate();
            this.controlButonDelegate5 = new controlThreadsWithDelegates.controlButonDelegate();
            this.controlButonDelegate6 = new controlThreadsWithDelegates.controlButonDelegate();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 139);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 243);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "label6";
            // 
            // controlButonDelegate1
            // 
            this.controlButonDelegate1.BackColor = System.Drawing.Color.Red;
            this.controlButonDelegate1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlButonDelegate1.Location = new System.Drawing.Point(118, 101);
            this.controlButonDelegate1.Name = "controlButonDelegate1";
            this.controlButonDelegate1.Size = new System.Drawing.Size(77, 24);
            this.controlButonDelegate1.TabIndex = 6;
            // 
            // controlButonDelegate2
            // 
            this.controlButonDelegate2.BackColor = System.Drawing.Color.Red;
            this.controlButonDelegate2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlButonDelegate2.Location = new System.Drawing.Point(154, 128);
            this.controlButonDelegate2.Name = "controlButonDelegate2";
            this.controlButonDelegate2.Size = new System.Drawing.Size(77, 24);
            this.controlButonDelegate2.TabIndex = 7;
            // 
            // controlButonDelegate3
            // 
            this.controlButonDelegate3.BackColor = System.Drawing.Color.Red;
            this.controlButonDelegate3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlButonDelegate3.Location = new System.Drawing.Point(177, 154);
            this.controlButonDelegate3.Name = "controlButonDelegate3";
            this.controlButonDelegate3.Size = new System.Drawing.Size(77, 24);
            this.controlButonDelegate3.TabIndex = 8;
            // 
            // controlButonDelegate4
            // 
            this.controlButonDelegate4.BackColor = System.Drawing.Color.Red;
            this.controlButonDelegate4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlButonDelegate4.Location = new System.Drawing.Point(204, 180);
            this.controlButonDelegate4.Name = "controlButonDelegate4";
            this.controlButonDelegate4.Size = new System.Drawing.Size(77, 24);
            this.controlButonDelegate4.TabIndex = 9;
            // 
            // controlButonDelegate5
            // 
            this.controlButonDelegate5.BackColor = System.Drawing.Color.Red;
            this.controlButonDelegate5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlButonDelegate5.Location = new System.Drawing.Point(229, 206);
            this.controlButonDelegate5.Name = "controlButonDelegate5";
            this.controlButonDelegate5.Size = new System.Drawing.Size(77, 24);
            this.controlButonDelegate5.TabIndex = 10;
            // 
            // controlButonDelegate6
            // 
            this.controlButonDelegate6.BackColor = System.Drawing.Color.Red;
            this.controlButonDelegate6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.controlButonDelegate6.Location = new System.Drawing.Point(250, 232);
            this.controlButonDelegate6.Name = "controlButonDelegate6";
            this.controlButonDelegate6.Size = new System.Drawing.Size(77, 24);
            this.controlButonDelegate6.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 473);
            this.Controls.Add(this.controlButonDelegate6);
            this.Controls.Add(this.controlButonDelegate5);
            this.Controls.Add(this.controlButonDelegate4);
            this.Controls.Add(this.controlButonDelegate3);
            this.Controls.Add(this.controlButonDelegate2);
            this.Controls.Add(this.controlButonDelegate1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private controlButonDelegate controlButonDelegate1;
        private controlButonDelegate controlButonDelegate2;
        private controlButonDelegate controlButonDelegate3;
        private controlButonDelegate controlButonDelegate4;
        private controlButonDelegate controlButonDelegate5;
        private controlButonDelegate controlButonDelegate6;
    }
}

